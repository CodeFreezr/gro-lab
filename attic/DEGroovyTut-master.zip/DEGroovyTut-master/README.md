DEGroovyTut
===========

Deutsches Groovy Kurztutorial

Der Quelltext unter groovy/tutorial.groovy beschreibt die Beispiele in den leidlich ausführlichen Kommentaren. Es
soll ein Überblick über die Sprache gegeben werden, der sich nicht an Einsteiger in die Programmierung wendet
aber nicht auf Java-Programmierer festgelegt ist.
